# NY FarmNet Sponsor Outreach Engine

A source-verified sponsor outreach workflow for NY FarmNet.

## Phase 1 status

This scaffold implements Phase 1: app skeleton + manual evidence workflow.

Implemented:

- React + Vite app shell
- Tailwind CSS styling
- Company input screen
- Staff notes and outreach-approval checkbox
- Manual evidence-entry workflow
- Evidence cards with type, text, source URL, source excerpt, confidence, verified, and rejected states
- Source URL validation and normalization
- Gate-status preview
- Draft prospect persistence in browser `localStorage`
- Live Research and Analyze buttons stubbed for later phases

## AI trust design

The project is designed around one rule:

> No verified evidence -> no AI-generated outreach.

Phase 1 already encodes the gate logic that later phases will enforce before any Claude analysis or generation runs. A finding cannot be verified unless it has:

1. finding text
2. a valid source URL
3. a source excerpt

The gate requires at least one verified company overview and one verified relevant company priority.

## Data persistence

Current in-progress prospects are saved in this browser through `localStorage`.

A production version would use Supabase, Airtable, or another shared database owned by FarmNet.

## What is intentionally scoped out for Phase 1

- No Claude API calls
- No live web research
- No generation of cold emails or one-pagers
- No full pipeline tracker
- No login/auth
- No shared database
- No real FarmNet sponsor data in the repo

## Run locally

```bash
npm install
npm run dev
```

## Build locally

```bash
npm run build
npm run preview
```

## Environment variables

No environment variables are needed for Phase 1.

Later phases should use server-side environment variables only:

- `ANTHROPIC_API_KEY`
- `DEMO_ACCESS_CODE`

Never commit `.env` files or private FarmNet data to GitHub.
