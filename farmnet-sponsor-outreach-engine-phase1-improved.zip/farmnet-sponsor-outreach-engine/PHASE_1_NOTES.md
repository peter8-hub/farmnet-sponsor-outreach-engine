# Phase 1 Notes

This phase creates the front-end foundation for the NY FarmNet Sponsor Outreach Engine.

## Implemented

- App shell and header
- Phase progress nav
- Input step
- Manual evidence step
- Evidence card component
- Fixed FarmNet constants
- Basic input validation
- Evidence source URL validation
- Evidence gate preview
- Draft persistence in localStorage
- Clear draft action
- Disabled future buttons for Live Research and Analyze Fit

## Improvements made after first scaffold

- Added finding factory helpers and `crypto.randomUUID` fallback
- Added quick buttons for required evidence types
- Added starter-card flow for the two required finding categories
- Enforced valid source URLs before a finding can be marked verified
- Automatically prevents rejected findings from also being verified
- Normalizes website and source URLs
- Improved gate preview with verified and total counts
- Added source-opening links on evidence cards
- Made draft-saving less noisy on initial page load

## Not implemented yet

- Claude API calls
- Serverless functions
- Live research
- Analyze endpoint
- Generate endpoint
- Pipeline tracker
- CSV export

## Next phase

Phase 2 should add:

- Hard verify-gate enforcement
- `/api/analyze`
- Claude analysis using only verified findings
- Editable analysis output fields
