import { CONFIDENCE_LEVELS, FINDING_TYPES } from "../data/farmnetConstants";
import { getFindingValidation, looksLikeUrl, normalizeUrl } from "../utils/validation";

export default function EvidenceCard({ finding, onChange, onDelete }) {
  const validation = getFindingValidation(finding);
  const sourceUrlIsValid = looksLikeUrl(finding.sourceUrl);

  function update(field, value) {
    const next = { ...finding, [field]: value };

    if (field === "sourceUrl") {
      next.sourceUrl = value;
    }

    if (field === "rejected" && value === true) {
      next.verified = false;
    }

    if (field === "verified" && value === true) {
      const nextValidation = getFindingValidation({ ...next, verified: false });
      if (!nextValidation.canVerify) return;
      next.rejected = false;
    }

    if (["text", "sourceUrl", "sourceExcerpt"].includes(field) && next.verified) {
      const nextValidation = getFindingValidation(next);
      if (!nextValidation.canVerify) {
        next.verified = false;
      }
    }

    onChange(next);
  }

  function normalizeSourceUrlOnBlur() {
    if (sourceUrlIsValid) {
      update("sourceUrl", normalizeUrl(finding.sourceUrl));
    }
  }

  const cardState = finding.rejected
    ? "Rejected"
    : finding.verified
    ? "Verified"
    : "Unverified";

  return (
    <article
      className={`rounded-2xl border p-5 shadow-sm ${
        finding.rejected
          ? "border-red-200 bg-red-50/60"
          : finding.verified
          ? "border-green-300 bg-green-50/50"
          : "border-stone-200 bg-white"
      }`}
    >
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="font-semibold">Evidence finding</h3>
            <span
              className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                finding.rejected
                  ? "bg-red-100 text-red-800"
                  : finding.verified
                  ? "bg-green-100 text-green-900"
                  : "bg-stone-100 text-stone-600"
              }`}
            >
              {cardState}
            </span>
          </div>
          <p className="mt-1 text-xs text-stone-500">
            Only verified, non-rejected findings will be eligible for Claude analysis.
          </p>
        </div>
        <button
          type="button"
          onClick={onDelete}
          className="rounded-lg border border-stone-300 px-3 py-1.5 text-xs font-medium text-stone-600 hover:bg-stone-50"
        >
          Delete
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <label className="grid gap-2">
          <span className="text-sm font-medium">Finding type</span>
          <select
            value={finding.type}
            onChange={(event) => update("type", event.target.value)}
            className="rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
          >
            {FINDING_TYPES.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-medium">Confidence</span>
          <select
            value={finding.confidence}
            onChange={(event) => update("confidence", event.target.value)}
            className="rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
          >
            {CONFIDENCE_LEVELS.map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label className="mt-4 grid gap-2">
        <span className="text-sm font-medium">Finding text</span>
        <textarea
          value={finding.text}
          onChange={(event) => update("text", event.target.value)}
          className="min-h-24 rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
          placeholder="Write the actual finding in one or two clear sentences."
        />
      </label>

      <label className="mt-4 grid gap-2">
        <span className="text-sm font-medium">Source URL</span>
        <input
          value={finding.sourceUrl}
          onChange={(event) => update("sourceUrl", event.target.value)}
          onBlur={normalizeSourceUrlOnBlur}
          className="rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
          placeholder="https://..."
        />
        {finding.sourceUrl && !sourceUrlIsValid && (
          <span className="text-xs font-medium text-red-700">Enter a valid source URL.</span>
        )}
        {sourceUrlIsValid && (
          <a
            href={normalizeUrl(finding.sourceUrl)}
            target="_blank"
            rel="noreferrer"
            className="text-xs font-medium text-green-800 underline underline-offset-2"
          >
            Open source
          </a>
        )}
      </label>

      <label className="mt-4 grid gap-2">
        <span className="text-sm font-medium">Source excerpt</span>
        <textarea
          value={finding.sourceExcerpt}
          onChange={(event) => update("sourceExcerpt", event.target.value)}
          className="min-h-24 rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
          placeholder="Paste the exact source excerpt or a short support note tied to the source."
        />
      </label>

      <div className="mt-4 flex flex-wrap gap-4 rounded-xl bg-white/70 p-3">
        <label
          className={`flex items-center gap-2 text-sm font-medium ${
            validation.canVerify ? "text-stone-900" : "text-stone-400"
          }`}
        >
          <input
            type="checkbox"
            checked={finding.verified}
            disabled={!validation.canVerify && !finding.verified}
            onChange={(event) => update("verified", event.target.checked)}
            className="h-4 w-4 rounded border-stone-300 text-green-800 focus:ring-green-700 disabled:cursor-not-allowed disabled:opacity-50"
          />
          Verified
        </label>

        <label className="flex items-center gap-2 text-sm font-medium">
          <input
            type="checkbox"
            checked={finding.rejected}
            onChange={(event) => update("rejected", event.target.checked)}
            className="h-4 w-4 rounded border-stone-300 text-red-700 focus:ring-red-700"
          />
          Rejected
        </label>
      </div>

      {!validation.canVerify && !finding.rejected && (
        <div className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-900">
          Verification requires finding text, a valid source URL, and a source excerpt.
        </div>
      )}
    </article>
  );
}
