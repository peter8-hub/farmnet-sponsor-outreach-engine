import EvidenceCard from "./EvidenceCard";
import { getEvidenceGateStatus } from "../utils/validation";
import { createEmptyFinding, createRequiredStarterFindings } from "../utils/findingFactory";

function GateItem({ label, passed }) {
  return (
    <li className="flex items-center justify-between gap-3 rounded-lg border border-stone-200 bg-white px-3 py-2 text-sm">
      <span>{label}</span>
      <span className={passed ? "font-semibold text-green-800" : "font-semibold text-stone-400"}>
        {passed ? "Ready" : "Missing"}
      </span>
    </li>
  );
}

export default function StepEvidence({ prospect, setProspect, onBack }) {
  const gate = getEvidenceGateStatus(prospect.evidenceFindings);

  function addFinding(type = "Company overview") {
    setProspect((previous) => ({
      ...previous,
      evidenceFindings: [...previous.evidenceFindings, createEmptyFinding(type)],
    }));
  }

  function addRequiredStarterFindings() {
    setProspect((previous) => ({
      ...previous,
      evidenceFindings: [...previous.evidenceFindings, ...createRequiredStarterFindings()],
    }));
  }

  function updateFinding(nextFinding) {
    setProspect((previous) => ({
      ...previous,
      evidenceFindings: previous.evidenceFindings.map((finding) =>
        finding.id === nextFinding.id ? nextFinding : finding
      ),
    }));
  }

  function deleteFinding(id) {
    setProspect((previous) => ({
      ...previous,
      evidenceFindings: previous.evidenceFindings.filter((finding) => finding.id !== id),
    }));
  }

  return (
    <section className="grid gap-6">
      <div className="rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold">Step 2 — Evidence</h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-stone-600">
              Add source-backed findings manually. Later phases will use only verified findings for Claude analysis and draft generation.
            </p>
          </div>
          <button
            type="button"
            onClick={onBack}
            className="rounded-xl border border-stone-300 px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50"
          >
            Back to Input
          </button>
        </div>

        <div className="mt-5 grid gap-3 rounded-xl bg-stone-50 p-4 text-sm md:grid-cols-2">
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wide text-stone-500">Company</span>
            <span className="mt-1 block font-medium">{prospect.companyName || "—"}</span>
          </div>
          <div>
            <span className="block text-xs font-semibold uppercase tracking-wide text-stone-500">Website</span>
            <a
              href={prospect.websiteUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-1 block break-all font-medium text-green-800 underline underline-offset-2"
            >
              {prospect.websiteUrl || "—"}
            </a>
          </div>
          {prospect.notes && (
            <div className="md:col-span-2">
              <span className="block text-xs font-semibold uppercase tracking-wide text-stone-500">Notes</span>
              <span className="mt-1 block whitespace-pre-wrap text-stone-700">{prospect.notes}</span>
              <span className="mt-2 inline-block rounded-full bg-stone-200 px-3 py-1 text-xs font-medium text-stone-700">
                {prospect.notesApprovedForOutreach
                  ? "Approved for outreach use"
                  : "Background only; excluded from drafts"}
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="grid gap-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-lg font-semibold">Evidence findings</h3>
              <p className="mt-1 text-sm text-stone-600">
                Required: one verified overview and one verified relevant company priority.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {prospect.evidenceFindings.length === 0 && (
                <button
                  type="button"
                  onClick={addRequiredStarterFindings}
                  className="rounded-xl bg-green-800 px-4 py-2 text-sm font-semibold text-white hover:bg-green-900"
                >
                  Add starter cards
                </button>
              )}
              <button
                type="button"
                onClick={() => addFinding("Company overview")}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50"
              >
                + Overview
              </button>
              <button
                type="button"
                onClick={() => addFinding("Relevant company priority")}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50"
              >
                + Priority
              </button>
              <button
                type="button"
                onClick={() => addFinding("Other")}
                className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-sm font-semibold text-stone-700 hover:bg-stone-50"
              >
                + Other
              </button>
            </div>
          </div>

          {prospect.evidenceFindings.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-stone-300 bg-white p-8 text-center text-sm text-stone-500">
              No evidence yet. Add starter cards to create the two required findings.
            </div>
          ) : (
            prospect.evidenceFindings.map((finding) => (
              <EvidenceCard
                key={finding.id}
                finding={finding}
                onChange={updateFinding}
                onDelete={() => deleteFinding(finding.id)}
              />
            ))
          )}
        </div>

        <aside className="h-fit rounded-2xl border border-stone-200 bg-white p-5 shadow-sm lg:sticky lg:top-6">
          <h3 className="text-base font-semibold">Gate preview</h3>
          <p className="mt-2 text-sm leading-6 text-stone-600">
            Phase 2 will use this gate to unlock Claude analysis. The gate is intentionally source-first.
          </p>

          <ul className="mt-4 grid gap-2">
            <GateItem label="Verified company overview" passed={gate.hasCompanyOverview} />
            <GateItem label="Verified relevant company priority" passed={gate.hasRelevantPriority} />
            <GateItem label="Verified findings have text, valid source URL, and excerpt" passed={gate.verifiedAllHaveSources} />
            <GateItem label="No rejected finding used downstream" passed={gate.noRejectedUsed} />
          </ul>

          <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl bg-stone-50 p-4 text-sm">
            <div>
              <span className="block font-semibold">Verified</span>
              <span className="mt-1 block text-2xl font-bold text-green-900">{gate.verifiedCount}</span>
            </div>
            <div>
              <span className="block font-semibold">Total</span>
              <span className="mt-1 block text-2xl font-bold text-stone-700">{gate.totalCount}</span>
            </div>
          </div>

          <button
            type="button"
            disabled
            className={`mt-5 w-full rounded-xl px-4 py-3 text-sm font-semibold text-white ${
              gate.canAnalyze ? "bg-green-700" : "bg-stone-300"
            }`}
          >
            {gate.canAnalyze ? "Gate Ready — Analyze in Phase 2" : "Analyze Fit — Phase 2"}
          </button>

          <p className="mt-3 text-xs leading-5 text-stone-500">
            Claude analysis will be added after the manual evidence workflow is stable.
          </p>
        </aside>
      </div>
    </section>
  );
}
