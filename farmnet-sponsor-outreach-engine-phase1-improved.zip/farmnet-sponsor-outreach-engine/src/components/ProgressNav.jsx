import { PHASE_ONE_STEPS } from "../data/farmnetConstants";

export default function ProgressNav({ currentStep }) {
  return (
    <nav className="mb-6 flex gap-3" aria-label="Progress">
      {PHASE_ONE_STEPS.map((step, index) => {
        const active = step.id === currentStep;
        return (
          <div
            key={step.id}
            className={`flex items-center rounded-full border px-4 py-2 text-sm font-medium ${
              active
                ? "border-green-700 bg-green-50 text-green-900"
                : "border-stone-200 bg-white text-stone-500"
            }`}
          >
            <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-white text-xs shadow-sm">
              {index + 1}
            </span>
            {step.label}
          </div>
        );
      })}
    </nav>
  );
}
