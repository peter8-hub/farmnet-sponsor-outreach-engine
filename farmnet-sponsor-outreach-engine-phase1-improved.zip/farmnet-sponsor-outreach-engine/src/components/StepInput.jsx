import { getInputErrors } from "../utils/validation";

export default function StepInput({ prospect, setProspect, onContinue }) {
  const errors = getInputErrors(prospect);
  const canContinue = Object.keys(errors).length === 0;

  function updateField(field, value) {
    setProspect((previous) => ({ ...previous, [field]: value }));
  }

  return (
    <section className="rounded-2xl border border-stone-200 bg-white p-6 shadow-sm">
      <div className="mb-6">
        <h2 className="text-xl font-semibold">Step 1 — Input</h2>
        <p className="mt-2 text-sm leading-6 text-stone-600">
          Enter the prospect basics. Staff notes can help later analysis, but they should never include confidential farmer or client information.
        </p>
      </div>

      <div className="grid gap-5">
        <label className="grid gap-2">
          <span className="text-sm font-medium">Company name *</span>
          <input
            className="rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
            value={prospect.companyName}
            onChange={(event) => updateField("companyName", event.target.value)}
            placeholder="Example: Chobani"
          />
          {errors.companyName && (
            <span className="text-xs text-red-700">{errors.companyName}</span>
          )}
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-medium">Website URL *</span>
          <input
            className="rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
            value={prospect.websiteUrl}
            onChange={(event) => updateField("websiteUrl", event.target.value)}
            placeholder="https://www.company.com"
          />
          {errors.websiteUrl && (
            <span className="text-xs text-red-700">{errors.websiteUrl}</span>
          )}
        </label>

        <label className="grid gap-2">
          <span className="text-sm font-medium">Staff notes</span>
          <textarea
            className="min-h-28 rounded-xl border border-stone-300 bg-white px-4 py-3 outline-none focus:border-green-700 focus:ring-2 focus:ring-green-100"
            value={prospect.notes}
            onChange={(event) => updateField("notes", event.target.value)}
            placeholder="Optional: known contacts, conference context, prior conversations, timing notes. Do not enter confidential farmer/client information."
          />
        </label>

        <label className="flex gap-3 rounded-xl border border-stone-200 bg-stone-50 p-4">
          <input
            type="checkbox"
            className="mt-1 h-4 w-4 rounded border-stone-300 text-green-800 focus:ring-green-700"
            checked={prospect.notesApprovedForOutreach}
            onChange={(event) =>
              updateField("notesApprovedForOutreach", event.target.checked)
            }
          />
          <span>
            <span className="block text-sm font-medium">
              Approved for outreach use; contains no confidential farmer/client information.
            </span>
            <span className="mt-1 block text-xs leading-5 text-stone-600">
              If unchecked, notes may inform analysis later as background context, but will not appear in generated drafts.
            </span>
          </span>
        </label>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          type="button"
          disabled={!canContinue}
          onClick={onContinue}
          className="rounded-xl bg-green-800 px-5 py-3 text-sm font-semibold text-white shadow-sm hover:bg-green-900 disabled:cursor-not-allowed disabled:bg-stone-300"
        >
          Continue to Evidence
        </button>
        <button
          type="button"
          disabled
          className="rounded-xl border border-stone-300 bg-stone-100 px-5 py-3 text-sm font-semibold text-stone-500"
          title="Live research will be added later. Use manual evidence entry for now."
        >
          Run Live Research — later phase
        </button>
      </div>
    </section>
  );
}
