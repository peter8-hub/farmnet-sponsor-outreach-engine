export default function AppShell({ children }) {
  return (
    <div className="min-h-screen bg-stone-50 text-stone-950">
      <header className="border-b border-stone-200 bg-white">
        <div className="mx-auto max-w-6xl px-5 py-6">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-green-800">
            NY FarmNet
          </p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight">
            Sponsor Outreach Engine
          </h1>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-stone-600">
            Source-verified sponsor outreach workflow. No verified evidence → no AI-generated outreach.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 py-8">{children}</main>
    </div>
  );
}
