export const VERTICALS = [
  "Financial Services",
  "FinTech",
  "AgTech & Equipment",
  "Ag Supply Chain",
  "Food Brands",
  "Sustainability",
  "Other / Review",
];

export const VALUE_PROPS = [
  "Trusted Network Access",
  "Pilot & Testing",
  "Rural Market Intelligence",
  "ESG & Sustainability",
  "Education Platform",
];

export const FINDING_TYPES = [
  "Company overview",
  "Relevant company priority",
  "ESG / ag / sustainability initiative",
  "Decision-maker signal",
  "Budget-cycle signal",
  "Other",
];

export const CONFIDENCE_LEVELS = ["High", "Medium", "Low"];

export const PHASE_ONE_STEPS = [
  { id: "input", label: "Input" },
  { id: "evidence", label: "Evidence" },
];
