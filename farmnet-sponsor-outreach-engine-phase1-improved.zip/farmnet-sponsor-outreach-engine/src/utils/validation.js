export function looksLikeUrl(value) {
  if (!value || !value.trim()) return false;

  try {
    const normalized = normalizeUrl(value);
    const url = new URL(normalized);
    return ["http:", "https:"].includes(url.protocol) && Boolean(url.hostname && url.hostname.includes("."));
  } catch {
    return false;
  }
}

export function normalizeUrl(value) {
  if (!value || !value.trim()) return "";
  const trimmed = value.trim();
  return trimmed.startsWith("http://") || trimmed.startsWith("https://")
    ? trimmed
    : `https://${trimmed}`;
}

export function getInputErrors(prospect) {
  const errors = {};

  if (!prospect.companyName.trim()) {
    errors.companyName = "Company name is required.";
  }

  if (!prospect.websiteUrl.trim()) {
    errors.websiteUrl = "Website URL is required.";
  } else if (!looksLikeUrl(prospect.websiteUrl)) {
    errors.websiteUrl = "Enter a valid website URL.";
  }

  return errors;
}

export function getFindingValidation(finding) {
  const errors = {};

  if (!finding.text?.trim()) {
    errors.text = "Finding text is required before this can be verified.";
  }

  if (!finding.sourceUrl?.trim()) {
    errors.sourceUrl = "A source URL is required before this can be verified.";
  } else if (!looksLikeUrl(finding.sourceUrl)) {
    errors.sourceUrl = "Enter a valid source URL.";
  }

  if (!finding.sourceExcerpt?.trim()) {
    errors.sourceExcerpt = "A source excerpt is required before this can be verified.";
  }

  if (finding.rejected) {
    errors.rejected = "Rejected findings cannot be verified.";
  }

  return {
    errors,
    canVerify: Object.keys(errors).length === 0,
  };
}

export function getEvidenceGateStatus(findings) {
  const verified = findings.filter((finding) => finding.verified && !finding.rejected);

  const hasCompanyOverview = verified.some(
    (finding) => finding.type === "Company overview"
  );

  const hasRelevantPriority = verified.some(
    (finding) => finding.type === "Relevant company priority"
  );

  const verifiedAllHaveSources = verified.every((finding) => {
    const validation = getFindingValidation(finding);
    return validation.canVerify;
  });

  const noRejectedUsed = findings.every(
    (finding) => !(finding.verified && finding.rejected)
  );

  return {
    canAnalyze:
      hasCompanyOverview &&
      hasRelevantPriority &&
      verifiedAllHaveSources &&
      noRejectedUsed,
    hasCompanyOverview,
    hasRelevantPriority,
    verifiedAllHaveSources,
    noRejectedUsed,
    verifiedCount: verified.length,
    totalCount: findings.length,
  };
}
