const DRAFT_KEY = "farmnet_current_prospect";

export function saveDraftProspect(prospect) {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(prospect));
  } catch (error) {
    console.warn("Unable to save draft prospect to localStorage", error);
  }
}

export function loadDraftProspect() {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    console.warn("Unable to load draft prospect from localStorage", error);
    return null;
  }
}

export function clearDraftProspect() {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch (error) {
    console.warn("Unable to clear draft prospect from localStorage", error);
  }
}
