export function createId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return `finding_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

export function createEmptyFinding(type = "Company overview") {
  return {
    id: createId(),
    type,
    text: "",
    sourceUrl: "",
    sourceExcerpt: "",
    confidence: "Medium",
    verified: false,
    rejected: false,
  };
}

export function createRequiredStarterFindings() {
  return [
    createEmptyFinding("Company overview"),
    createEmptyFinding("Relevant company priority"),
  ];
}
