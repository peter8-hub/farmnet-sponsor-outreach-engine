import { useEffect, useMemo, useRef, useState } from "react";
import AppShell from "./components/AppShell";
import ProgressNav from "./components/ProgressNav";
import StepInput from "./components/StepInput";
import StepEvidence from "./components/StepEvidence";
import { loadDraftProspect, saveDraftProspect, clearDraftProspect } from "./utils/localStorage";
import { normalizeUrl } from "./utils/validation";

const emptyProspect = {
  companyName: "",
  websiteUrl: "",
  notes: "",
  notesApprovedForOutreach: false,
  evidenceFindings: [],
  analysis: null,
  generatedDrafts: null,
};

function sanitizeLoadedProspect(loaded) {
  if (!loaded) return emptyProspect;

  return {
    ...emptyProspect,
    ...loaded,
    evidenceFindings: Array.isArray(loaded.evidenceFindings) ? loaded.evidenceFindings : [],
  };
}

export default function App() {
  const [currentStep, setCurrentStep] = useState("input");
  const [prospect, setProspect] = useState(() => sanitizeLoadedProspect(loadDraftProspect()));
  const [showSavedNotice, setShowSavedNotice] = useState(false);
  const hasMounted = useRef(false);

  useEffect(() => {
    if (!hasMounted.current) {
      hasMounted.current = true;
      return;
    }

    const saveTimer = setTimeout(() => {
      saveDraftProspect(prospect);
      setShowSavedNotice(true);
    }, 250);

    const noticeTimer = setTimeout(() => setShowSavedNotice(false), 1200);

    return () => {
      clearTimeout(saveTimer);
      clearTimeout(noticeTimer);
    };
  }, [prospect]);

  const hasDraft = useMemo(() => {
    return Boolean(
      prospect.companyName ||
        prospect.websiteUrl ||
        prospect.notes ||
        prospect.evidenceFindings.length
    );
  }, [prospect]);

  function continueToEvidence() {
    setProspect((previous) => ({
      ...previous,
      companyName: previous.companyName.trim(),
      websiteUrl: normalizeUrl(previous.websiteUrl),
      notes: previous.notes.trim(),
    }));
    setCurrentStep("evidence");
  }

  function resetDraft() {
    const confirmed = window.confirm(
      "Clear the current draft prospect from this browser? This cannot be undone."
    );

    if (!confirmed) return;

    clearDraftProspect();
    setProspect(emptyProspect);
    setCurrentStep("input");
  }

  return (
    <AppShell>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <ProgressNav currentStep={currentStep} />
        <div className="flex items-center gap-3 text-xs text-stone-500">
          {showSavedNotice && <span>Draft saved locally</span>}
          {hasDraft && (
            <button
              type="button"
              onClick={resetDraft}
              className="rounded-lg border border-stone-300 bg-white px-3 py-2 font-medium text-stone-600 hover:bg-stone-50"
            >
              Clear draft
            </button>
          )}
        </div>
      </div>

      {currentStep === "input" && (
        <StepInput
          prospect={prospect}
          setProspect={setProspect}
          onContinue={continueToEvidence}
        />
      )}

      {currentStep === "evidence" && (
        <StepEvidence
          prospect={prospect}
          setProspect={setProspect}
          onBack={() => setCurrentStep("input")}
        />
      )}
    </AppShell>
  );
}
